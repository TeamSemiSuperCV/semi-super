#/bin/sh

curl https://bootstrap.pypa.io/get-pip.py -o get-pip.py
python3 get-pip.py
PATH=~/.local/bin:$PATH

curl https://gist.githubusercontent.com/ankitmundada/7d15bc85ff1430d99a8467767c8ed2d2/raw/5b957d9f8a8b5ec5e48491602e645d76ac9a6b52/download_gdrive -o gd.sh
pip3 install tensorflow tensorflow-datasets==4.4.0
