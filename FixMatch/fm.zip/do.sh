#/bin/sh

export ML_DATA="./data"
export PYTHONPATH=.:$PYTHONPATH
export TF_CPP_MIN_LOG_LEVEL=2

DATASET="xray"
TRAIN_DIR="./experiments"
IMG_H=150
IMG_W=150
FILTERS=24
BATCH=8
LABELS=250
KIMG=1024

PYTHON=python3

if [ $# -gt 0 ] && [ $1 == "create" ]
then
  rm -rf $ML_DATA
  $PYTHON scripts/create_datasets.py $DATASET --img_h=$IMG_H --img_w=$IMG_W
  $PYTHON scripts/create_unlabeled.py $ML_DATA/SSL2/xray $ML_DATA/$DATASET-train.tfrecord
  for seed in 1; do
    for size in 250; do
      $PYTHON scripts/create_split.py --seed=$seed --size=$size $ML_DATA/SSL2/$DATASET $ML_DATA/$DATASET-train.tfrecord
    done
  done
fi

rm -rf $TRAIN_DIR
$PYTHON fixmatch.py --filters=$FILTERS --train_kimg=$KIMG --img_h=$IMG_H --img_w=$IMG_W --batch=$BATCH --dataset=$DATASET.1@$LABELS-1 --train_dir $TRAIN_DIR
